//
//  ViewController.swift
//  CollapseTask
//
//  Created by Parghi Infotech on 08/01/18.
//  Copyright © 2018 Parghi Infotech. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UITableViewDragDelegate {
    
    @IBOutlet weak var tableview: UITableView!
    
    var groups = [String]()
    var sectionNames = [String]()
    
//    var fruits = [String]()
    var fruits : String = ""
  
    var expandedSectionHeaderNumber: Int = -1
    let kHeaderSectionTag: Int = 6900;
    
    var tableDataFirst = [String]()
    var tableDataSecond = [String]()
    var tableDataThird = [String]()
    
    var userdef1 : [String] = [String]()
    var userdef2 : [String] = [String]()
    var userdef3 : [String] = [String]()
    var userDefaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        sectionNames = ["Animal","Birds","Fruits"]
        print(APPDELEGATE.keyArray1)
    }
    
    override func viewWillAppear(_ animated: Bool) {
//        groups = [[]]
//        print(groups)
//        fruits = []
        print(APPDELEGATE.mainCategory)
        print(APPDELEGATE.values)
        print(APPDELEGATE.pickerOption)
        
        print(tableDataFirst)
        var userdefArray = UserDefaults.standard.object(forKey: APPDELEGATE.keyArray1)
        print(userdefArray)
        
        // First Cell
        userdef1 = UserDefaults.standard.object(forKey: APPDELEGATE.key) as! [String]
        print(userdef1)
        
        // Second cell
        userdef2 = UserDefaults.standard.object(forKey: APPDELEGATE.key2) as! [String]
        print(userdef2)
        
        // Third cell
        userdef3 = UserDefaults.standard.object(forKey: APPDELEGATE.key3) as! [String]
        print(userdef3)
    
        // Check elements is in an Array yes/not
        if sectionNames.contains(APPDELEGATE.mainCategory)
        {
            // Find item index
            let itemIndex:Int = sectionNames.index(of: APPDELEGATE.mainCategory)!
            print(itemIndex)
            
            if itemIndex == 0 {
                tableDataFirst.append(userdef1[userdef1.count - 1])
                tableview.reloadData()
            }
            else if itemIndex == 1 {
                tableDataSecond.append(userdef2[userdef2.count - 1])
                tableview.reloadData()
            }
            else if itemIndex == 2 {
                tableDataThird.append(userdef3[userdef3.count - 1])
                tableview.reloadData()
            }
        }
        else
        {
            tableDataFirst = userdef1
            tableDataSecond = userdef2
            tableDataThird = userdef3
            tableview.reloadData()
        }
        
//        if APPDELEGATE.values != ""
//        {
//            fruits.append(APPDELEGATE.values)
//            print(fruits)
//            groups.append(fruits)
//            print(groups)
//            tableview.reloadData()
//        }
        
//        fruits = ["Apple"]
//        groups.append(fruits)
        
//        let Vegetables = ["Carrot", "Broccoli", "Cucumber"]
//        groups.append(Vegetables)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionNames.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if (self.expandedSectionHeaderNumber == section) {
//            let arrayOfItems = self.groups[section] as! NSArray
//            return arrayOfItems.count;
//        } else {
//            return 0;
//        }
        if section == 0 {
            return tableDataFirst.count
        }
        else if section == 1 {
            return tableDataSecond.count
        }
        else if section == 2 {
            return tableDataThird.count
        }
        return 0
    }
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//
////        if (self.sectionNames.count != 0) {
////            return self.sectionNames[section] as? String
////        }
////        return ""
//        //return sectionNames[section] as! String
//    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if section == 0
        {
            let headerCell1 = tableView.dequeueReusableCell(withIdentifier: "cell1") as! tableViewCellFirst
            headerCell1.lableName.text = "Animal"
            headerCell1.contentView.backgroundColor = UIColor(red: 230.0/255.0, green: 110.0/255.0, blue: 102.0/255.0, alpha: 1.0)
            return headerCell1
        }
        else if section == 1
        {
            let headerCell2 = tableView.dequeueReusableCell(withIdentifier: "cell2") as! tableViewCellSecond
            headerCell2.lableName2.text = "Birds"
            headerCell2.contentView.backgroundColor = UIColor(red: 113.0/255.0, green: 220.0/255.0, blue: 110.0/255.0, alpha: 1.0)
            return headerCell2
        }
        
        else if section == 2
        {
             let headerCell3 = tableView.dequeueReusableCell(withIdentifier: "cell3") as! tableViewCellThird
            headerCell3.lableName3.text = "Fruits"
            headerCell3.contentView.backgroundColor = UIColor(red: 230.0/255.0, green: 110.0/255.0, blue: 102.0/255.0, alpha: 1.0)
            return headerCell3
        }
        
//        headerCell.headerCellSection = section
//        print(headerCell.headerCellSection)
//
//        let headerTapGesture = UITapGestureRecognizer()
//        headerTapGesture.addTarget(self, action: #selector(buttonTapped))
//        headerCell.addGestureRecognizer(headerTapGesture)
//
        return UIView()
    }
//
    @objc func buttonTapped(sender:UITapGestureRecognizer) {

        if sender.state == .ended {
            print("section pressed")
        }
//        let senderView = sender.view as! tableViewCellFirst
//        print(senderView)
//
//        // Get the section
//        let section = senderView.headerCellSection
//        print(section)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44.0;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
//
//        let section = self.groups[indexPath.section] as! NSArray
//        cell.textLabel?.text = section[indexPath.row] as! String
//
//        return cell
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! tableViewCellFirst
            
            let row = indexPath.row
            print(row)
            
            cell.lableName.text = tableDataFirst[row]
            
            return cell
        }
            
        else if indexPath.section == 1 {
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! tableViewCellSecond

            let row = indexPath.row
            print(row)

            cell2.lableName2.text = tableDataSecond[row]

            return cell2
        }

        else if indexPath.section == 2 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell3", for: indexPath) as! tableViewCellThird

            let row = indexPath.row
            print(row)

            cell.lableName3.text = tableDataThird[row]

            return cell
        }
        
        return UITableViewCell()
        
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete {
//            print("Deleted")
//
//            if indexPath.section == 0 {
//                self.tableDataFirst.remove(at: indexPath.row)
//                self.tableview.deleteRows(at: [indexPath], with: .automatic)
//            }
//            else if indexPath.section == 1 {
//                self.tableDataSecond.remove(at: indexPath.row)
//                self.tableview.deleteRows(at: [indexPath], with: .automatic)
//            }
//            else if indexPath.section == 2 {
//                self.tableDataThird.remove(at: indexPath.row)
//                self.tableview.deleteRows(at: [indexPath], with: .automatic)
//            }
//        }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
       
        let update = UITableViewRowAction(style: .normal, title: "Update") { action, index in
            print("update")
        }
        
        let delete = UITableViewRowAction(style: .normal, title: "Delete") { action, index in
            
            if indexPath.section == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! tableViewCellFirst
                
                let row = indexPath.row
                self.tableDataFirst.remove(at: indexPath.row)
                self.tableview.deleteRows(at: [indexPath], with: .automatic)
                self.userDefaults.set(self.tableDataFirst, forKey: APPDELEGATE.key)
                tableView.reloadData()
            }
            else if indexPath.section == 1 {
                self.tableDataSecond.remove(at: indexPath.row)
                self.tableview.deleteRows(at: [indexPath], with: .automatic)
                self.userDefaults.set(self.tableDataSecond, forKey: APPDELEGATE.key2)
                tableView.reloadData()
            }
            else if indexPath.section == 2 {
                self.tableDataThird.remove(at: indexPath.row)
                self.tableview.deleteRows(at: [indexPath], with: .automatic)
                self.userDefaults.set(self.tableDataThird, forKey: APPDELEGATE.key3)
                tableView.reloadData()
            }
        }
        
        return [update,delete]
    }
    
  /*  func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView
        header.contentView.backgroundColor = UIColor.brown
        header.textLabel?.textColor = UIColor.white
        
        if let viewWithTag = self.view.viewWithTag(kHeaderSectionTag + section) {
            viewWithTag.removeFromSuperview()
        }
        let headerFrame = self.view.frame.size
        let theImageView = UIImageView(frame: CGRect(x: headerFrame.width - 32, y: 13, width: 18, height: 18));
        theImageView.image = UIImage(named: "Chevron-Dn-Wht")
        theImageView.tag = kHeaderSectionTag + section
        header.addSubview(theImageView)
        
        // make headers touchable
        header.tag = section
        let headerTapGesture = UITapGestureRecognizer()
        headerTapGesture.addTarget(self, action: #selector(ViewController.sectionHeaderWasTouched(_:)))
        header.addGestureRecognizer(headerTapGesture)
    }
    
    @objc func sectionHeaderWasTouched(_ sender: UITapGestureRecognizer) {
        let headerView = sender.view as! UITableViewHeaderFooterView
        let section    = headerView.tag
        let eImageView = headerView.viewWithTag(kHeaderSectionTag + section) as? UIImageView
        
        if (self.expandedSectionHeaderNumber == -1) {
            self.expandedSectionHeaderNumber = section
            tableViewExpandSection(section, imageView: eImageView!)
        } else {
            if (self.expandedSectionHeaderNumber == section) {
                tableViewCollapeSection(section, imageView: eImageView!)
            } else {
                let cImageView = self.view.viewWithTag(kHeaderSectionTag + self.expandedSectionHeaderNumber) as? UIImageView
                tableViewCollapeSection(self.expandedSectionHeaderNumber, imageView: cImageView!)
                tableViewExpandSection(section, imageView: eImageView!)
            }
        }
    } */
    
    //MARK: ExpandableMewthods
   /* func tableViewCollapeSection(_ section: Int, imageView: UIImageView) {
        let sectionData = self.groups[section] as! NSArray
        
        self.expandedSectionHeaderNumber = -1;
        if (sectionData.count == 0) {
            return;
        } else {
            UIView.animate(withDuration: 0.4, animations: {
                imageView.transform = CGAffineTransform(rotationAngle: (0.0 * CGFloat(Double.pi)) / 180.0)
            })
            var indexesPath = [IndexPath]()
            for i in 0 ..< sectionData.count {
                let index = IndexPath(row: i, section: section)
                indexesPath.append(index)
            }
            self.tableview!.beginUpdates()
            self.tableview!.deleteRows(at: indexesPath, with: UITableViewRowAnimation.fade)
            self.tableview!.endUpdates()
        }
    }
    */

   /* func tableViewExpandSection(_ section: Int, imageView: UIImageView) {
        let sectionData = self.groups[section] as! NSArray
        
        if (sectionData.count == 0) {
            self.expandedSectionHeaderNumber = -1;
            return;
        } else {
            UIView.animate(withDuration: 0.4, animations: {
                imageView.transform = CGAffineTransform(rotationAngle: (180.0 * CGFloat(Double.pi)) / 180.0)
            })
            var indexesPath = [IndexPath]()
            for i in 0 ..< sectionData.count {
                let index = IndexPath(row: i, section: section)
                indexesPath.append(index)
            }
            self.expandedSectionHeaderNumber = section
            self.tableview!.beginUpdates()
            self.tableview!.insertRows(at: indexesPath, with: UITableViewRowAnimation.fade)
            self.tableview!.endUpdates()
        }
    } */
    
    //MARK: buttonAddDataClicked
    @IBAction func buttonAddDataClicked(_ sender: Any) {
        let addDataVC = self.storyboard?.instantiateViewController(withIdentifier: "AddDataViewController") as! AddDataViewController
        
        addDataVC.tableFirstData = tableDataFirst
        addDataVC.tableSecondData = tableDataSecond
        addDataVC.tableThirdData = tableDataThird
        
        self.navigationController?.pushViewController(addDataVC, animated: true)
    }
}

class tableViewCellFirst:UITableViewCell {
    @IBOutlet weak var lableName: UILabel!
    var headerCellSection:Int?
}

class tableViewCellSecond:UITableViewCell {
    @IBOutlet weak var lableName2: UILabel!
}

class tableViewCellThird:UITableViewCell {
    @IBOutlet weak var lableName3: UILabel!
}


