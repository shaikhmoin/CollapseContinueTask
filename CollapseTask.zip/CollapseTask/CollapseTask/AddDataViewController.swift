//
//  AddDataViewController.swift
//  CollapseTask
//
//  Created by Parghi Infotech on 08/01/18.
//  Copyright © 2018 Parghi Infotech. All rights reserved.
//

import UIKit

class AddDataViewController: UIViewController,UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var textFieldCategoryType: UITextField!
    @IBOutlet weak var textFieldSubCategoryType: UITextField!
    
    var pickerOption = ["Animal","Birds","Fruits"]
    var tableFirstData = [String]()
    var tableSecondData = [String]()
    var tableThirdData = [String]()
    
//    var tableData = ["a"]
    var tableData = [String]()
    var tableData2 = [String]()
    var tableData3 = [String]()
    
    var userDefaults = UserDefaults.standard
    
    //MARK: UIView Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        
        print(tableFirstData)
        print(tableSecondData)
        
        textFieldCategoryType.delegate = self
        textFieldSubCategoryType.delegate = self
        
        let pickerView = UIPickerView()
        pickerView.delegate = self
        textFieldCategoryType.inputView = pickerView
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        textFieldSubCategoryType.resignFirstResponder()
        textFieldCategoryType.resignFirstResponder()
    }
    //MARK: UITextfield Methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return pickerOption[section] as! String
    }
    
    //MARK: UIPickerView Data Source Methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerOption.count
    }
    
    //MARK: UIPickerView Delegate Methods
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerOption[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        textFieldCategoryType.text = pickerOption[row]
    }
    
    //UITableView Methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return tableData.count
        }
        else if section == 1 {
            return tableData2.count
        }
        else if section == 2 {
            return tableData3.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! tableViewCell
            
            let row = indexPath.row
            print(row)
            
            cell.lableName.text = tableData[row]
            
            return cell
        }
        
        else if indexPath.section == 1 {
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! tableViewCell2

            let row = indexPath.row
            print(row)

            cell2.lableName2.text = tableData2[row]

            return cell2
        }
        
        else if indexPath.section == 2 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell3", for: indexPath) as! tableViewCell3

            let row = indexPath.row
            print(row)

            cell.lableName3.text = tableData3[row]

            return cell
        }
        
        
        return UITableViewCell()
    }
    
    //MARK: submitData
    @IBAction func buttonSumit(_ sender: Any) {
        let pickerValue = textFieldCategoryType.text

//        let buttonPosition = (sender as AnyObject).convert(CGPoint.zero, to: self.tableView)
//        let indexPath = self.tableView.indexPathForRow(at: buttonPosition)
        
        // get index value(0,1,2) from array
        if pickerOption.contains(textFieldCategoryType.text!)
        {
            let a:Int = pickerOption.index(of: textFieldCategoryType.text!)!
            print(a)

            if a == 0 {
               print("Hi")
                tableData.append(textFieldSubCategoryType.text!)
            }
            else if a == 1 {
                 tableData2.append(textFieldSubCategoryType.text!)
            }
            else if a == 2 {
                tableData3.append(textFieldSubCategoryType.text!)
            }
        }
   
        
        //VIew Controller Page code
        let mainVC = self.storyboard?.instantiateViewController(withIdentifier: "mainVC") as! ViewController

        APPDELEGATE.values = textFieldSubCategoryType.text!
        print(APPDELEGATE.values)
    
        APPDELEGATE.mainCategory = pickerValue!
//        UserDefaults.standard.set(APPDELEGATE.values, forKey: APPDELEGATE.key)
//        print(APPDELEGATE.key)

        APPDELEGATE.pickerOption = pickerOption

        // First Table
        if pickerValue == "Animal"
        {
            tableFirstData.append(textFieldSubCategoryType.text!)
            print(tableFirstData)
            userDefaults.set(tableFirstData, forKey: APPDELEGATE.key)
            print(tableFirstData)
        }
       
        // Second Table
        if pickerValue == "Birds"
        {
            tableSecondData.append(textFieldSubCategoryType.text!)
            print(tableSecondData)
            userDefaults.set(tableSecondData, forKey: APPDELEGATE.key2)
            print(tableSecondData)
        }
        
        if pickerValue == "Fruits"
        {
            tableThirdData.append(textFieldSubCategoryType.text!)
            print(tableThirdData)
            userDefaults.set(tableThirdData, forKey: APPDELEGATE.key3)
            print(tableThirdData)
        }
        
//        if let itemObj = userDefaults.array(forKey: APPDELEGATE.keyArray1) {
//        var items = itemObj
//            items.append(textFieldSubCategoryType.text ?? "")
//        }
 
//        if let itemsObjects = UserDefaults.standard.array(forKey: APPDELEGATE.keyArray1) {
//            var items = itemsObjects
//            items.append(textField.text!)
//        }
        
//        var strValue = ""
//        strValue = userDefaults.string(forKey: "Gratitude")!
//        gratitudeArray.append(strValue)
        //UserDefaults.standard.set(a, forKey: APPDELEGATE.keyArray1)
        
        navigationController?.popViewController(animated: true)
        
        //test VIew Controller Page code
//        let mainVC = self.storyboard?.instantiateViewController(withIdentifier: "testVC") as! testViewController
//        APPDELEGATE.testvalue = textFieldSubCategoryType.text!
//        print(APPDELEGATE.testvalue)
////        APPDELEGATE.values = textFieldSubCategoryType.text!
////        print(APPDELEGATE.values)
////        APPDELEGATE.mainCategory = pickerValue!
//
//        navigationController?.popViewController(animated: true)
        
        //self.tableView.reloadData()
    }
}

class tableViewCell:UITableViewCell {
    @IBOutlet weak var lableName: UILabel!
}

class tableViewCell2:UITableViewCell {
    @IBOutlet weak var lableName2: UILabel!
}

class tableViewCell3:UITableViewCell {
    @IBOutlet weak var lableName3: UILabel!
}
